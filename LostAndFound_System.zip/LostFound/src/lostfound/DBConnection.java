
package lostfound;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/cite_lost_found";

    private static final String USER = "root";
    private static final String PASSWORD = "";

    private DBConnection() {
        // Prevent creating an instance of this class.
    }

    // Connect to the MySQL database.
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Keep this method if other classes use DBConnection.now().
    public static String now() {
        return LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        );
    }

    // Keep compatibility with classes that use connect().
    public static Connection connect() throws SQLException {
        return getConnection();
    }
}
