/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lostfound;

import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author User
 */
public class Homepage extends javax.swing.JFrame {
    private TableRowSorter<DefaultTableModel> sorter;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Homepage.class.getName());

    /**
     * Creates new form Homepage
     */
        public Homepage() {
        initComponents();
        

        // Make the Lost and Found list scroll vertically.
        jScrollPane1.setVerticalScrollBarPolicy(
                javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        jScrollPane1.setHorizontalScrollBarPolicy(
                javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.getVerticalScrollBar().setUnitIncrement(16);

               USER.setText(UserSeassion.username);

                setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
                setMinimumSize(new java.awt.Dimension(900, 600));
                setLocationRelativeTo(null);

                jPanel14.setLayout(
                new javax.swing.BoxLayout(
                jPanel14,
                javax.swing.BoxLayout.Y_AXIS
                )
            );

                displayPostsFromDatabase();
                loadSummary();

                jButton1.addActionListener(
                    e -> validateCaptionBeforeReport("lost")
                );

                jButton2.addActionListener(
                    e -> validateCaptionBeforeReport("found")
                );
            }

            private void displayPostsFromDatabase() {
                jPanel14.removeAll();

                jPanel14.setLayout(
                    new javax.swing.BoxLayout(
                        jPanel14,
                        javax.swing.BoxLayout.Y_AXIS
                    )
                );
                jPanel14.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

                // jLabel29 is the actual list heading created by initComponents().
                jPanel14.add(jLabel29);

                String sql =
                    "SELECT l.item_id, l.caption, l.item_image, l.item_name, " +
                    "l.item_location, l.item_date, l.item_description, " +
                    "l.item_reportedby AS reported_by, s.status_name AS item_status, " +
                    "l.created_at, 'LOST' AS report_type " +
                    "FROM lostitems_tb l " +
                    "LEFT JOIN status_tb s ON l.status_id = s.status_id " +

                    "UNION ALL " +

                    "SELECT f.item_id, f.caption, f.item_image, f.item_name, " +
                    "f.item_location, f.item_date, f.item_description, " +
                    "f.item_foundby AS reported_by, s.status_name AS item_status, " +
                    "f.created_at, 'FOUND' AS report_type " +
                    "FROM founditems_tb f " +
                    "LEFT JOIN status_tb s ON f.status_id = s.status_id " +

                    "ORDER BY created_at DESC";

                boolean hasPosts = false;

                try (
                    java.sql.Connection con = DBConnection.connect();
                    java.sql.PreparedStatement pst =
                        con.prepareStatement(sql);
                    java.sql.ResultSet rs = pst.executeQuery()
                ) {
                    while (rs.next()) {
                        hasPosts = true;

                        int itemId = rs.getInt("item_id");

                        String caption = rs.getString("caption");
                        String imagePath = rs.getString("item_image");
                        String itemName = rs.getString("item_name");
                        String location = rs.getString("item_location");
                        String date = rs.getString("item_date");
                        String description = rs.getString("item_description");
                        String reportedBy = rs.getString("reported_by");
                        String type = rs.getString("report_type");
                        String status = rs.getString("item_status");

                        if (status == null || status.trim().isEmpty()) {
                            status = "Unknown";
                        }

                        JPanel post = new JPanel(
                            new java.awt.BorderLayout(10, 10)
                        );

                        post.setBackground(java.awt.Color.WHITE);

                        post.setBorder(
                            javax.swing.BorderFactory.createCompoundBorder(
                                javax.swing.BorderFactory.createLineBorder(
                                    java.awt.Color.LIGHT_GRAY
                                ),
                                javax.swing.BorderFactory.createEmptyBorder(
                                    12, 12, 12, 12
                                )
                            )
                        );

                        post.setAlignmentX(
                            java.awt.Component.LEFT_ALIGNMENT
                        );

                        post.setMaximumSize(
                            new java.awt.Dimension(
                                Integer.MAX_VALUE, 420
                            )
                        );

                        javax.swing.JLabel details = new javax.swing.JLabel(
                            "<html><div style='width:500px;'>" +
                            "<b>" + escapeHtml(type) + " ITEM</b><br><br>" +
                            "<b>Caption:</b> " + escapeHtml(caption) + "<br>" +
                            "<b>Item:</b> " + escapeHtml(itemName) + "<br>" +
                            "<b>Location:</b> " + escapeHtml(location) + "<br>" +
                            "<b>Date:</b> " + escapeHtml(date) + "<br>" +
                            "<b>Description:</b> " +
                                escapeHtml(description) + "<br>" +
                            "<b>Reported by:</b> " +
                                escapeHtml(reportedBy) + "<br>" +
                            "<b>Status:</b> " + escapeHtml(status) +
                            "</div></html>"
                        );

                        details.setFont(
                            new java.awt.Font(
                                "Arial",
                                java.awt.Font.PLAIN,
                                14
                            )
                        );

                        post.add(details, java.awt.BorderLayout.NORTH);

                        javax.swing.JLabel picture =
                            new javax.swing.JLabel("No image available");

                        picture.setHorizontalAlignment(
                            javax.swing.JLabel.CENTER
                        );

                        picture.setPreferredSize(
                            new java.awt.Dimension(300, 200)
                        );

                        if (imagePath != null && !imagePath.isBlank()) {
                            java.io.File file =
                                new java.io.File(imagePath);

                            if (file.isFile()) {
                                javax.swing.ImageIcon original =
                                    new javax.swing.ImageIcon(imagePath);

                                java.awt.Image scaled =
                                    original.getImage().getScaledInstance(
                                        300,
                                        200,
                                        java.awt.Image.SCALE_SMOOTH
                                    );

                                picture.setText("");
                                picture.setIcon(
                                    new javax.swing.ImageIcon(scaled)
                                );
                            }
                        }

                        post.add(picture, java.awt.BorderLayout.CENTER);

                        // Only found items can be claimed.
                        
                if ("FOUND".equalsIgnoreCase(type)) {

                    javax.swing.JButton claimButton =
                        new javax.swing.JButton("Claim Item");

                    claimButton.setBackground(new java.awt.Color(0, 160, 60));
                    claimButton.setForeground(java.awt.Color.WHITE);
                    claimButton.setFocusPainted(false);

                    // Open ClaimRequest when clicked
                    claimButton.addActionListener(e -> {
                        try {
                           ClaimRequest request = new ClaimRequest(itemId);
                            request.setLocationRelativeTo(this);
                            request.setVisible(true);

                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(
                                this,
                                "Cannot open Claim Request:\n" + ex.getMessage(),
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                            );
                        }
                    });

                    javax.swing.JPanel buttonPanel =
                        new javax.swing.JPanel(
                            new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT)
                        );

                    buttonPanel.setBackground(java.awt.Color.WHITE);
                    buttonPanel.add(claimButton);

                    post.add(buttonPanel, java.awt.BorderLayout.SOUTH);
                }


                        jPanel14.add(post);

                        jPanel14.add(
                            javax.swing.Box.createVerticalStrut(12)
                        );
                    }

                    if (!hasPosts) {
                        jPanel14.add(
                            new javax.swing.JLabel(
                                "No lost or found items reported yet."
                            )
                        );
                    }

                } catch (java.sql.SQLException e) {
                    javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Unable to load posts from the database:\n"
                            + e.getMessage(),
                        "Database Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE
                    );
                }

                jPanel14.revalidate();
                jPanel14.repaint();
            }

            private int countRecords(String sql) {
                try (
                    java.sql.Connection con = DBConnection.connect();
                    java.sql.PreparedStatement pst =
                        con.prepareStatement(sql);
                    java.sql.ResultSet rs = pst.executeQuery()
                ) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }

                } catch (java.sql.SQLException e) {
                    javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Unable to load summary:\n" + e.getMessage(),
                        "Database Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE
                    );
                }

                return 0;
            }

            private void loadSummary() {
                int lost = countRecords(
                    "SELECT COUNT(*) FROM lostitems_tb"
                );

                int found = countRecords(
                    "SELECT COUNT(*) FROM founditems_tb"
                );

                // Assumes claim_tb uses status_id as a foreign key.
                int pending = countRecords(
                    "SELECT COUNT(*) FROM claim_tb c " +
                    "JOIN status_tb s ON c.status_id = s.status_id " +
                    "WHERE s.status_name = 'Pending'"
                );

                int successfulClaims = countRecords(
                    "SELECT COUNT(*) FROM claim_tb c " +
                    "JOIN status_tb s ON c.status_id = s.status_id " +
                    "WHERE s.status_name IN ('Approved', 'Returned')"
                );

                int successfulReturns = countRecords(
                    "SELECT COUNT(*) FROM claim_tb " +
                    "WHERE returned_at IS NOT NULL"
                );

                jLabel16.setText("Lost Items: " + lost);
                jLabel17.setText("Found Items: " + found);
                jLabel18.setText("Pending Claims: " + pending);
                jLabel19.setText("Successful Claims: " + successfulClaims);
                jLabel20.setText("Successful Returns: " + successfulReturns);
            }

            private void validateCaptionBeforeReport(String reportType) {
                String caption = txtCaption.getText().trim();

                if (caption.isEmpty()) {
                    javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Please type a caption before reporting a "
                            + reportType + " item.",
                        "Caption Required",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                    );

                    txtCaption.requestFocusInWindow();
                    return;
                }

                javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Caption received:\n" + caption +
                    "\n\nConnect this button to your " + reportType +
                    " item form to save the caption.",
                    "Caption Ready",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE
                );
            }

            private JPanel createPostCard(
                String caption,
                String imagePath,
                int itemId
            ) {
                JPanel card = new JPanel(
                    new java.awt.BorderLayout(10, 10)
                );

                card.setBorder(
                    javax.swing.BorderFactory.createCompoundBorder(
                        javax.swing.BorderFactory.createLineBorder(
                            java.awt.Color.LIGHT_GRAY
                        ),
                        javax.swing.BorderFactory.createEmptyBorder(
                            12, 12, 12, 12
                        )
                    )
                );

                card.setBackground(java.awt.Color.WHITE);

                card.setAlignmentX(
                    java.awt.Component.LEFT_ALIGNMENT
                );

                card.setMaximumSize(
                    new java.awt.Dimension(Integer.MAX_VALUE, 400)
                );

                javax.swing.JLabel captionLabel =
                    new javax.swing.JLabel(
                        "<html><div style='width:500px;'>" +
                        escapeHtml(caption) +
                        "</div></html>"
                    );

                captionLabel.setFont(
                    new java.awt.Font(
                        "Arial",
                        java.awt.Font.BOLD,
                        15
                    )
                );

                card.add(captionLabel, java.awt.BorderLayout.NORTH);

                javax.swing.JLabel imageLabel =
                    new javax.swing.JLabel("No image available");

                imageLabel.setHorizontalAlignment(
                    javax.swing.JLabel.CENTER
                );

                imageLabel.setPreferredSize(
                    new java.awt.Dimension(300, 220)
                );

                if (imagePath != null && !imagePath.isBlank()) {
                    java.io.File file = new java.io.File(imagePath);

                    if (file.isFile()) {
                        javax.swing.ImageIcon original =
                            new javax.swing.ImageIcon(imagePath);

                        java.awt.Image scaled =
                            original.getImage().getScaledInstance(
                                300,
                                220,
                                java.awt.Image.SCALE_SMOOTH
                            );

                        imageLabel.setText("");
                        imageLabel.setIcon(
                            new javax.swing.ImageIcon(scaled)
                        );
                    }
                }

                card.add(imageLabel, java.awt.BorderLayout.CENTER);

                return card;
            }

            private String escapeHtml(String text) {
                if (text == null) {
                    return "";
                }

                return text.replace("&", "&amp;")
                           .replace("<", "&lt;")
                           .replace(">", "&gt;")
                           .replace("\"", "&quot;")
                           .replace("'", "&#39;");
            }

            private void displayPost(
                String caption,
                String imagePath,
                int itemId
            ) {
                JPanel card = createPostCard(
                    caption,
                    imagePath,
                    itemId
                );

                jPanel14.add(card);

                jPanel14.add(
                    javax.swing.Box.createVerticalStrut(12)
                );

                jPanel14.revalidate();
                jPanel14.repaint();
            }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        USER = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        txtCaption = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel14 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(235, 235, 235));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 51));
        jLabel2.setText("CITE Lost & Found ");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pic2.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        jButton10.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jButton10.setText("Pofile");
        jButton10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton10.addActionListener(this::jButton10ActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/slazzer-preview-nzok3 (1).png"))); // NOI18N
        jLabel3.setText("jLabel3");

        USER.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        USER.setText("USER");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(USER)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(USER)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jButton6.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jButton6.setText("Home");
        jButton6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jButton7.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jButton7.setText("My Claim");
        jButton7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton7.addActionListener(this::jButton7ActionPerformed);

        jButton9.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jButton9.setText("Log Out");
        jButton9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton9.addActionListener(this::jButton9ActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel15.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel15.setText("Reported Summary");

        jLabel16.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel16.setText("Lost Items");

        jLabel17.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel17.setText("Found Items");

        jLabel18.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel18.setText("Pending Claims");

        jLabel19.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel19.setText("Successful Claims");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jLabel19)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel20.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel20.setText("Successful Returns");

        jLabel13.setFont(new java.awt.Font("Arial Narrow", 2, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("Items successfully returned to their verified");

        jLabel21.setFont(new java.awt.Font("Arial Narrow", 2, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(153, 153, 153));
        jLabel21.setText("owners through the CITE Office.");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel13)
                    .addComponent(jLabel21))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Report Lost Item");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(0, 153, 51));
        jButton2.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Report Find Item");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/slazzer-preview-nzok3 (4).png"))); // NOI18N
        jLabel4.setText("jLabel4");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(436, 436, 436)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCaption))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        jLabel29.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel29.setText("Lost And Found List:");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29)
                .addContainerGap(476, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel14);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        MyClaims myclaims = new MyClaims();
        myclaims.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
            int confirm;
            confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to logout?",
                    "Logout Confirmation",
                    JOptionPane.YES_NO_OPTION
            );

        if (confirm == JOptionPane.YES_OPTION) {

            Login login = new Login(); // your login form name
            login.setVisible(true);

            this.dispose(); // close current form
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        Homepage homepage = new Homepage();
        homepage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        Profile profile = new Profile();
        profile.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       ReportLostItem lost = new ReportLostItem();
        lost.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ReportFoundItem found = new ReportFoundItem();
        found.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Homepage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel USER;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCaption;
    // End of variables declaration//GEN-END:variables

    private void claimItem(int itemId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
