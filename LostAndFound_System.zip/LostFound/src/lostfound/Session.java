package lostfound;

/**
 * Holds the currently authenticated user for the duration of the session.
 *
 * @author CITE Lost &amp; Found
 */
public final class Session {

    private static User currentUser;

    private Session() {
        // utility class
    }

    public static User getUser() {
        return currentUser;
    }

    public static void setUser(User user) {
        currentUser = user;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static boolean isAdmin() {
        return currentUser != null && "Cite Admin".equalsIgnoreCase(currentUser.getRole());
    }

    public static void logout() {
        currentUser = null;
    }
}
