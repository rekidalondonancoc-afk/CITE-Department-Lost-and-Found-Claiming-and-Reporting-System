package lostfound;

/**
 * A registered user of the system. The {@code role} is one of
 * {@code "IT Student"}, {@code "Guest"} or {@code "Cite Admin"}.
 *
 * @author CITE Lost &amp; Found
 */
public class User {

    private int id;
    private String username;
    private String password;
    private String role;
    private String fullName;
    private String contact;
    private String email;
    private String createdAt;

    public User() {
    }

    public User(int id, String username, String role, String fullName, String contact, String email) {
        this.id = id;
        this.username = username;
        this.role = role;
        this.fullName = fullName;
        this.contact = contact;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /** @return the name to display in the UI (full name when available). */
    public String getDisplayName() {
        if (fullName != null && !fullName.trim().isEmpty()) {
            return fullName;
        }
        return username;
    }

    @Override
    public String toString() {
        return getDisplayName();
    }
}
