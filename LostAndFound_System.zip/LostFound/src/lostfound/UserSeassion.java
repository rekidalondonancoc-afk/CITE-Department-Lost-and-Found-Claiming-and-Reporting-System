
package lostfound;
import java.awt.Component;
import javax.swing.JOptionPane;

        public class UserSeassion {

            private static int userId;
            static String username;
            private static String role;
            private static boolean loggedIn = false;

            public static void startSession(
                    int id, String user, String userRole) {

                userId = id;
                username = user;
                role = userRole;
                loggedIn = true;
            }

            public static int getUserId() {
                return userId;
            }

            public static String getUsername() {
                return username;
            }

            public static String getRole() {
                return role;
            }

            public static boolean isLoggedIn() {
                return loggedIn;
            }

            public static void endSession() {
                userId = 0;
                username = null;
                role = null;
                loggedIn = false;
            }

            public static void error(Component parent, String message) {
                JOptionPane.showMessageDialog(
                        parent,
                        message,
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

            public static void info(Component parent, String message) {
                JOptionPane.showMessageDialog(
                        parent,
                        message,
                        "Information",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

            public static void warning(Component parent, String message) {
                JOptionPane.showMessageDialog(
                        parent,
                        message,
                        "Warning",
                        JOptionPane.WARNING_MESSAGE
                );
            }

    static void makeScrollable(Homepage aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        }